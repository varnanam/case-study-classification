# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 12:12:07 2022

@author: vivek
"""

from flask import Flask,render_template,request
import pickle
import numpy as np

model=pickle.load(open('iris.pkl','rb'))

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/result',methods=['POST'])
def result():
    SL=request.form['SL']
    SW=request.form['SW']
    PL=request.form['PL']
    PW=request.form['PW']
    arr=np.array([[SL,SW,PL,PW]])
    pred=model.predict(arr)
    return render_template('result.html',data=pred)

if __name__=='__main__':
    app.run(port=8000)
    