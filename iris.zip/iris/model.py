# -*- coding: utf-8 -*-
"""
Created on Sun Aug 21 12:11:21 2022

@author: vivek
"""

import pandas as pd
import pickle
import numpy as np
import matplotlib.pyplot as plt

#loading the dataset

df=pd.read_excel(r'C:\Users\vivek\OneDrive\Desktop\iris\iris.xls')

df.info()

#handling missing values

missing=df.groupby('Classification')['SL','SW','PL'].median()
for i in ['Iris-setosa','Iris-versicolor','Iris-virginica']:
    for j in['SL','SW','PL']:
        df.loc[df['Classification']==i,j]=df[df['Classification']==i][j].fillna(missing.loc[i,j])

#plotting the dataset

df[['SL', 'SW', 'PL', 'PW']].boxplot()
plt.show()

#handling outliers

q1=np.percentile(df['SW'],25,interpolation='midpoint')
q2=np.percentile(df['SW'],50,interpolation='midpoint')
q3=np.percentile(df['SW'],75,interpolation='midpoint')
IQR=q3-q1

low_lim=q1-(1.5*IQR)
up_lim=q3+(1.5*IQR)
print('Lower limit : ',low_lim)
print('Upper limit : ',up_lim)

outlier=[]
for x in df['SW']:
    if((x>up_lim) or (x<low_lim)):
        outlier.append(x)

out_idx=df['SW']<low_lim
df.loc[out_idx].index

out_idx=df['SW']>up_lim
df.loc[out_idx].index

df.drop([15, 32, 33,60],inplace=True)

X = df.drop(['Classification'],axis=1)
y= df['Classification']

#label encoding

from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
y=le.fit_transform(y)

#splitting the dataset

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,random_state=42)

from sklearn.svm import SVC
svc=SVC(kernel='linear').fit(X_train,y_train)

#saving the model
pickle.dump(svc,open(r'C:\Users\vivek\OneDrive\Desktop\iris\iris.pkl','wb'))
